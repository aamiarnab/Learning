import pandas as pd

# Load each table into a separate DataFrame
df_order = pd.read_csv("order.csv")
df_order_line = pd.read_csv("order_line.csv")
df_shipment = pd.read_csv("shipment.csv")
df_return = pd.read_csv("return.csv")
df_product = pd.read_csv("product.csv")
df_customer = pd.read_csv("customer.csv")
df_return_reason = pd.read_csv("return_reason_ref.csv")

df_scm_table_metadata = pd.read_csv("scm_table_metadata.csv")
df_scm_table_metadata.to_json("scm_dataframe_metadata.json", orient = "records")

query = "df_return[df_return['return_reason_code'] == 'DAMAGED'] \
    .merge(df_shipment, on='shipment_id') \
    .merge(df_order, on='order_id') \
    ['total_amount'].sum()"

output = eval(query)

print(output)

#print(df_scm_table_metadata.head())

'''# Optional: Preview each DataFrame
print("Orders:\n", df_order.head())
print("Order Line Items:\n", df_order_line.head())
print("Shipments:\n", df_shipment.head())
print("Returns:\n", df_return.head())
print("Drugs:\n", df_product.head())
print("Customers:\n", df_customer.head())
print("Return Reasons:\n", df_return_reason.head())
'''
