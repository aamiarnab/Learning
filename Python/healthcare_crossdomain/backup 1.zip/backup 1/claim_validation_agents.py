#pip install langchain sentence-transformers chromadb pandas scikit-learn

from dis import Instruction
import pandas as pd
from langchain.docstore.document import Document
from sklearn.metrics.pairwise import cosine_similarity
from langchain_huggingface import HuggingFaceEmbeddings
#from langchain_community.vectorstores import Chroma
from langchain_chroma import Chroma
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
import os
from dotenv import load_dotenv
import json
from bs4 import BeautifulSoup


load_dotenv()

# This tool creates the knowledge fabric for the clinical notes and build relationship with the patient demographics 
def create_knowledge_fabric(uploaded_df, collection_name):
    try:
        # Convert to LangChain Documents
        docs = [
            Document(page_content= row.to_csv(), metadata={"patient_id": row["Patient ID"]})
            for _, row in uploaded_df.iterrows()
        ]

        embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        vector_db = Chroma.from_documents(documents=docs, embedding=embedding_model, collection_name=collection_name, persist_directory="./patient_db")
        #vector_db.persist()
        msg = f"✅ Successfully loaded {collection_name} ."
       
    except Exception as e:
        msg = f" ❌ Error while updated knowledge fabric for {collection_name}: {e}"

    return msg


def seach_knowledge_fabric(query, collection_name, persist_directory):

    embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = Chroma(collection_name=collection_name, embedding_function=embedding_model,persist_directory=persist_directory) 
    results = vectorstore.similarity_search(query=query,k=5)
    #results = vectorstore.similarity_search_with_score(query=query,k=5)
    print("output from ChromaDB:")
    for i, doc in enumerate(results):
        print(f"\nResult {i+1}:")
        print("Content:", doc.page_content)
        print("Metadata:", doc.metadata)

    return results

# Generate prompt for talk to data response
def talk_to_patient_360(query, data):
    prompt = f"You are a data query assistant who is helping to generate relevant answer \
        to the query from the data provided,\
        query: {query} \
        \
        data: {data}\
        \
        Enahnce the content provided into html format for better presentation in the chat window. \
        Highlight important aspects, use tables, bullets etc.as suitable. provide only the html sting as response"

    response = invoke_llm(prompt)
    response_html = response[7:-4]

    return response_html

# 
def find_patient_v2(claim_doc, from_fabric):
    
    query = "Provide patient id, name, occupation, clinical notes, diagnosis, payment method, claim description for this claim"

    prompt = f"You are a data query assistant helping users to find relevant patient data from claim document \
        Claim document contains the claim information\
        data contains data about patient \
        query contains the information required after matching claim docmnet and data \
        query: {query} \
        \
        data: {from_fabric}\
        \
        claim document: {claim_doc}\
        \
        response format: provide in following json format \
        patient_id: matched patient id\
        clinical_note: clinical note for the patient from data\
        claim_desc : descripton as given in the claim documnet \
        content : content as per the query. Enahnce the content provided into html format for better presentation in the chat window. \
        Highlight important aspects, use tables, bullets etc.as suitable. provide only the html sting as response"

    response = invoke_llm(prompt)
    response_json = json.loads(response[7:-4])

    return response_json

# Invoke llm to generate html output
def invoke_llm(user_input):
    print("In generate html response")

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.0-flash",
        google_api_key=os.environ["GOOGLE_API_KEY"]
    )

    # Define prompt template
    prompt = ChatPromptTemplate.from_template(
        "Respond only as per format suggested. Do not add any extra word or character \n\n{input}"
    )

    # Chain: prompt → model → string parser
    chain = prompt | llm | StrOutputParser()

    # Run the chain
    response = chain.invoke({"input": user_input})
    print(response)

    return response

# validate claim description againt clinical notes
def match_claim_to_note(clinical_note, claim_desc):

    embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

    # Embed claim and notes
    claim_vec = embedding_model.embed_query(claim_desc)
    note_vecs = embedding_model.embed_documents(clinical_note)

    # Compute similarity
    scores = cosine_similarity([claim_vec], note_vecs)[0]
    
    return scores




'''

#######

vectorstore = Chroma(collection_name=collection_name, embedding_function=embedding_model,persist_directory="./patient_db") 
all_data = vectorstore.get()
print("All documents in ChromaDB:")
for doc_content in all_data['documents']:
    print(doc_content)
#######


# validate claim description againt clinical notes
def match_claim_to_note(claims_df):

    for _, row in claims_df.iterrows():
        patient_id = row["Patient ID"]
        claim_id = row["Claim ID"]
        claim_text = row["Claim Description"]

    # Filter clinical notes for the same patient
    notes = [doc for doc in clinical_docs if doc.metadata["patient_id"] == patient_id]
    if not notes:
        return None, 0.0

    # Embed claim and notes
    claim_vec = embedding_model.embed_query(claim_text)
    note_vecs = embedding_model.embed_documents([note.page_content for note in notes])

    # Compute similarity
    scores = cosine_similarity([claim_vec], note_vecs)[0]
    best_score = max(scores)
    best_note = notes[scores.argmax()].page_content

    return best_note, best_score


def flag_mismatched_claims(claims_df, threshold=0.5):
    flagged = []

    for _, row in claims_df.iterrows():
        claim_text = row["Claim Description"]
        patient_id = row["Patient ID"]
        best_note, score = match_claim_to_note(claim_text, patient_id)

        #if score < threshold:
        flagged.append({
            "Claim ID": row["Claim ID"],
            "Patient ID": patient_id,
            "Claim Description": claim_text,
            "Best Matching Note": best_note,
            "Similarity Score": round(score, 2),
            "Status": "Rejected"
        })

    return pd.DataFrame(flagged)


'''



'''
flagged_df = flag_mismatched_claims(claims_df, threshold=0.5)
flagged_df.to_csv("flagged_claims.csv", index=False)
print(flagged_df.head())

            if uploaded_file_name == "patient_demography":
                patient_demography_df = uploaded_df
                log_container.write(" ✅ Successfully loaded patient demography")
                msg = cva.create_knowledge_fabric(uploaded_df, uploaded_file_name)
                log_container.write(msg)
            elif uploaded_file_name == "clinical_notes":
                clinical_notes_df = uploaded_df
                log_container.write(" ✅ Successfully loaded clinical notes")
                msg = cva.create_knowledge_fabric(uploaded_df, uploaded_file_name)
                log_container.write(msg)
            elif uploaded_file_name == "billing_data":
                billing_data_df = uploaded_df
                log_container.write(" ✅ Successfully loaded billing data")
                msg = cva.create_knowledge_fabric(uploaded_df, uploaded_file_name)
                log_container.write(msg)
            else:
                msg = f" ❌ Wrong file name : {uploaded_file_name} "


'''