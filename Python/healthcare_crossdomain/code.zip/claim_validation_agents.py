#pip install langchain sentence-transformers chromadb pandas scikit-learn

from dis import Instruction
import pandas as pd
from langchain.schema import Document
from sklearn.metrics.pairwise import cosine_similarity
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
import os
from dotenv import load_dotenv
import json
import streamlit as st
import zipfile
import os
import tempfile
from pypdf import PdfReader


load_dotenv()

# *** Newly added - Start

# Agent to create new collection in patient db
def create_new_collection(docs, collection_name, persist_directory):
    embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

    try:
        vector_db = Chroma.from_documents(documents=docs, embedding=embedding_model, collection_name=collection_name, persist_directory=persist_directory)
        #vector_db.persist()
        success = True
    except Exception as e:
        print (f" ❌ Error while updated knowledge fabric for {collection_name}: {e}")
        success = False

    return success

# Agent to create the knowledge fabric for the clinical notes and build relationship with the patient demographics 
def create_patient_360(patient_demography_df, clinical_notes_df, billing_data_df):
    documents = []

    # Group clinical and billing data by patient_id
    clinical_grouped = clinical_notes_df.groupby("Patient ID")
    billing_grouped = billing_data_df.groupby("Patient ID")

    for _, demo_row in patient_demography_df.iterrows():
        pid = demo_row["Patient ID"]

        # Demographic info
        demo_text = "\n".join([f"{col}: {demo_row[col]}" for col in demo_row.index if col != "Patient ID"])

        # Clinical notes
        clinical_notes = clinical_grouped.get_group(pid) if pid in clinical_grouped.groups else pd.DataFrame()
        clinical_text = "\n".join([
            f"- {row.to_dict()}" for _, row in clinical_notes.iterrows()
        ]) if not clinical_notes.empty else "No clinical notes available."

        # Billing data
        billing_entries = billing_grouped.get_group(pid) if pid in billing_grouped.groups else pd.DataFrame()
        billing_text = "\n".join([
            f"- {row.to_dict()}" for _, row in billing_entries.iterrows()
        ]) if not billing_entries.empty else "No billing records available."

        # Combine all into one document
        full_text = f"""Patient ID: {pid}

=== Demographics ===
{demo_text}

=== Clinical Notes ===
{clinical_text}

=== Billing Records ===
{billing_text}
"""
        documents.append(Document(page_content=full_text, metadata={"Patient ID": pid}))
    #print("This is merged document : \n", documents)

    if create_new_collection(documents, "patient_360", "./patient_db"):
        msg = f"✅ Successfully created knowledge fabric for patient_360 ."
    else:
        msg = f" ❌ Error while updated knowledge fabric for patient_360."
    #msg = True
    return msg

# Agent reads a zip of pdf files and convert them into a langchain doc ready to be merged with knowledge fabric
def zip_to_doc(uploaded_file):
    with tempfile.TemporaryDirectory() as temp_dir:
        zip_path = os.path.join(temp_dir, "uploaded.zip")
        with open(zip_path, "wb") as f:
            f.write(uploaded_file.read())

        # Extract ZIP contents
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(temp_dir)

        # Find all PDF files
        pdf_files = [os.path.join(temp_dir, f) for f in os.listdir(temp_dir) if f.lower().endswith(".pdf")]

        if not pdf_files:
            st.warning("No PDF files found in the ZIP.")
        else:
            st.success(f"Found {len(pdf_files)} PDF file(s). Processing...")

            documents = []

            for pdf_path in pdf_files:
                try:
                    reader = PdfReader(pdf_path)
                    text = ""
                    for page in reader.pages:
                        page_text = page.extract_text()
                        if page_text:
                            text += page_text + "\n"
                    #print("text outside for page", text)

                    doc = Document(
                        page_content=text,
                        metadata={"source": os.path.basename(pdf_path)}
                    )
                    documents.append(doc)
                except Exception as e:
                    print(f"Error processing {os.path.basename(pdf_path)}: {e}")
    return documents

def update_patient_360(claim_doc, collection_name, persist_directory):
    try:
        from_fabric = seach_knowledge_fabric(claim_doc, "patient_360", "./patient_db")
        response = find_patient_v2(claim_doc, from_fabric)
        patient_id = response["patient_id"]
        print("patient_id from response : ", "|"+patient_id+"|")
        embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        vectorstore = Chroma(collection_name=collection_name, embedding_function=embedding_model,persist_directory=persist_directory) 
        results = vectorstore.get(where={"Patient ID": patient_id})
        print("current document : ", type(results), results)
        doc_id = results["ids"]
        print("doc_id is : ", doc_id)
        print("current document content is :", type(results["documents"][0]), results["documents"][0])
        print("claim_doc is :", type(claim_doc), claim_doc)
        updated_content = f"""{results["documents"][0]}
=== Claim Records ===
{claim_doc}"""
        updated_document = Document(page_content=updated_content, metadata={"Patient ID": patient_id})
        vectorstore.update_documents(
            ids=doc_id,
            documents=[updated_document]
        )
        print("Updated document from ChromaDB:")
        print(vectorstore.get(where={"Patient ID": patient_id})["documents"][0])
        success = True

    except Exception as e:
        print(f"Error in updating claim document : {e}")
        success = False

    return success



# *** newly added - end

def seach_knowledge_fabric(query, collection_name, persist_directory):

    embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    vectorstore = Chroma(collection_name=collection_name, embedding_function=embedding_model,persist_directory=persist_directory) 
    results = vectorstore.similarity_search(query=query,k=5)
    #results = vectorstore.similarity_search_with_score(query=query,k=5)
    '''
    print("output from ChromaDB:")
    for i, doc in enumerate(results):
        print(f"\nResult {i+1}:")
        print("Content:", doc.page_content)
        print("Metadata:", doc.metadata)
'''
    return results

# Generate prompt for talk to data response
def talk_to_patient_360(query, data):
    prompt = f"You are a data query assistant who is helping to generate relevant answer \
        to the query from the data provided,\
        query: {query} \
        \
        data: {data}\
        \
        Enahnce the content provided into html format for better presentation in the chat window. \
        Highlight important aspects, use tables, bullets etc.as suitable. provide only the html sting as response"

    response = invoke_llm(prompt)
    response_html = response[7:-4]

    return response_html

# 
def find_patient_v2(claim_doc, from_fabric):
    
    query = "Provide patient id, name, occupation, clinical notes, diagnosis, payment method, claim description for this claim"

    prompt = f"You are a data query assistant helping users to find relevant patient data from claim document \
        Claim document contains the claim information\
        data contains data about patient \
        query contains the information required after matching claim docmnet and data \
        query: {query} \
        \
        data: {from_fabric}\
        \
        claim document: {claim_doc}\
        \
        response format: provide in following json format \
        patient_id: matched patient id\
        clinical_note: clinical note for the patient from data\
        claim_desc : descripton as given in the claim documnet \
        content : content as per the query. Enahnce the content provided into html format for better presentation in the chat window. \
        Highlight important aspects, use tables, bullets etc.as suitable. provide only the html sting as response"

    response = invoke_llm(prompt)
    response_json = json.loads(response[7:-4])

    return response_json

# Invoke llm to generate html output
def invoke_llm(user_input):

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.0-flash",
        google_api_key=os.environ["GOOGLE_API_KEY"]
    )

    # Define prompt template
    prompt = ChatPromptTemplate.from_template(
        "Respond only as per format suggested. Do not add any extra word or character \n\n{input}"
    )

    # Chain: prompt → model → string parser
    chain = prompt | llm | StrOutputParser()

    # Run the chain
    response = chain.invoke({"input": user_input})
    #print(response)

    return response

# validate claim description againt clinical notes
def match_claim_to_note(clinical_note, claim_desc):

    embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")

    # Embed claim and notes
    claim_vec = embedding_model.embed_query(claim_desc)
    note_vecs = embedding_model.embed_documents(clinical_note)

    # Compute similarity
    scores = cosine_similarity([claim_vec], note_vecs)[0]
    
    return scores




'''

####### Redundant function DELETE DELETE DELETE ############

def create_knowledge_fabric(uploaded_df, collection_name): # newly added -- this is now reduntant
    try:
        # Convert to LangChain Documents
        docs = [
            Document(page_content= row.to_csv(), metadata={"patient_id": row["Patient ID"]})
            for _, row in uploaded_df.iterrows()
        ]

        embedding_model = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        vector_db = Chroma.from_documents(documents=docs, embedding=embedding_model, collection_name=collection_name, persist_directory="./patient_db")
        #vector_db.persist()
        msg = f"✅ Successfully loaded {collection_name} ."
       
    except Exception as e:
        msg = f" ❌ Error while updated knowledge fabric for {collection_name}: {e}"

    return msg

#######


# validate claim description againt clinical notes
def match_claim_to_note(claims_df):

    for _, row in claims_df.iterrows():
        patient_id = row["Patient ID"]
        claim_id = row["Claim ID"]
        claim_text = row["Claim Description"]

    # Filter clinical notes for the same patient
    notes = [doc for doc in clinical_docs if doc.metadata["patient_id"] == patient_id]
    if not notes:
        return None, 0.0

    # Embed claim and notes
    claim_vec = embedding_model.embed_query(claim_text)
    note_vecs = embedding_model.embed_documents([note.page_content for note in notes])

    # Compute similarity
    scores = cosine_similarity([claim_vec], note_vecs)[0]
    best_score = max(scores)
    best_note = notes[scores.argmax()].page_content

    return best_note, best_score


def flag_mismatched_claims(claims_df, threshold=0.5):
    flagged = []

    for _, row in claims_df.iterrows():
        claim_text = row["Claim Description"]
        patient_id = row["Patient ID"]
        best_note, score = match_claim_to_note(claim_text, patient_id)

        #if score < threshold:
        flagged.append({
            "Claim ID": row["Claim ID"],
            "Patient ID": patient_id,
            "Claim Description": claim_text,
            "Best Matching Note": best_note,
            "Similarity Score": round(score, 2),
            "Status": "Rejected"
        })

    return pd.DataFrame(flagged)


'''



'''
flagged_df = flag_mismatched_claims(claims_df, threshold=0.5)
flagged_df.to_csv("flagged_claims.csv", index=False)
print(flagged_df.head())

            if uploaded_file_name == "patient_demography":
                patient_demography_df = uploaded_df
                log_container.write(" ✅ Successfully loaded patient demography")
                msg = cva.create_knowledge_fabric(uploaded_df, uploaded_file_name)
                log_container.write(msg)
            elif uploaded_file_name == "clinical_notes":
                clinical_notes_df = uploaded_df
                log_container.write(" ✅ Successfully loaded clinical notes")
                msg = cva.create_knowledge_fabric(uploaded_df, uploaded_file_name)
                log_container.write(msg)
            elif uploaded_file_name == "billing_data":
                billing_data_df = uploaded_df
                log_container.write(" ✅ Successfully loaded billing data")
                msg = cva.create_knowledge_fabric(uploaded_df, uploaded_file_name)
                log_container.write(msg)
            else:
                msg = f" ❌ Wrong file name : {uploaded_file_name} "


'''